package com.example.ku;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;


import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNavigationView;


    HomeFragment homeFragment;
    SearchFragment searchFragment;
    SettingFragment settingFragment;
    MenuFragment menuFragment;
    HaksaFragment haksaFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//      xml레이아웃 파일에 정의된 뷰들을 java 코드에서 사용하기 위해 식별, 초기화 하는 역할
        drawerLayout = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

//        프래그먼트 초기화
        //bottonavigation코드 - 하단 바
        homeFragment = new HomeFragment();
        searchFragment = new SearchFragment();
        settingFragment = new SettingFragment();
        menuFragment = new MenuFragment();

        //menu코드
        haksaFragment = new HaksaFragment();

        //초기화면 설정
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.containers, homeFragment)
                .commit();

        // BottomNavigationView 초기화
        NavigationBarView navigationBarView = findViewById(R.id.bottomNavigationView);
        navigationBarView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.menu:
//                        getSupportFragmentManager().beginTransaction()
//                                .replace(R.id.containers, menuFragment)
//                                .commit();
                        drawerLayout.openDrawer(GravityCompat.START);
                        return true;
                    case R.id.home:
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.containers, homeFragment)
                                .commit();
                        return true;
                    case R.id.search:
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.containers, searchFragment)
                                .commit();
                        return true;
                    case R.id.setting:
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.containers, settingFragment)
                                .commit();
                        return true;
                }
                drawerLayout.openDrawer(GravityCompat.START);
             return false;
            }
        });

        // navigationView 리스너 설정
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.one:
                        Log.d("MainActivity", "onNavigationItemSelected: Haksa menu selected"); // 로그 추가
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.containers, haksaFragment)
                                .commit();
//                        drawerLayout.closeDrawer(GravityCompat.START); // 메뉴 닫기
                       menuItem.setChecked(true);
                       drawerLayout.closeDrawer(GravityCompat.START);
                       return true;
                }
                return false;
            }
        });

    }

}